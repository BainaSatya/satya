let arr1 = [12,23,34,45,56,67,78];

len_arr1 = Math.floor(arr1.length/2);
console.log(arr1[len_arr1]);


let arr2 = ['html','css','java','python'];

len1_arr2 =  Math.floor((arr2.length-1)/2)                   
len2_arr2 = Math.floor(arr2.length/2);;
console.log(arr2[len1_arr2],arr2[len2_arr2]);