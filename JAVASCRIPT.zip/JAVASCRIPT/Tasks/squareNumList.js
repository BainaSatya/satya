function square_numbers(){
     var l = []
     for(var i=1; i<21; i++){
          l.push(i**2)
          
}      
console.log(l) 

}             
square_numbers()