
const question = (NaN && 12 || 'satya' && [] && -65 && 95 && '' || false && null || true || 19.6)

console.log(question);