let arr = ['HTML', 'CSS', 'JAVASCRIPT', 'BOOTSTRAP', 'NODE JS', 'REACT JS'];

let second_To_Last = arr[arr.length - 2];
console.log(second_To_Last);