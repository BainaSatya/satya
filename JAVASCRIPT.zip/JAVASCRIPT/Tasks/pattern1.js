var x,y,char;
for(x=1; x <=6; x++)
{
   for (y=1; y < x; y++)
     {
    char=char+(" * ");        
      }
 console.log(char);
 char='';    
}
