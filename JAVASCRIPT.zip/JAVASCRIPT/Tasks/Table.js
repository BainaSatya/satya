

var prompt = require("prompt-sync")();

let num = parseInt(prompt("Enter the Number : "))


for(let i = 1; i<11; i++){
     console.log(`${num} x ${i} = ${num*i}`) 
}  

