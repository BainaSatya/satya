// program to trim a string

const string = '      Hello World       ';

const result = string.split(' ').join('');

console.log(result);